from csv import DictReader
import psycopg2
import hashlib
import boto3

ssm = boto3.client('ssm')
parameter = ssm.get_parameter(Name='redshift-cluster-master-pass', WithDecryption=True)
PASS = parameter['Parameter']['Value'] # gets master redshift password

def lambda_handler(event, context):
    s3 = boto3.resource('s3')
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    print(key)
    s3.meta.client.download_file(bucket, key, '/tmp/data_list.csv')
    extract_transaction_data('/tmp/data_list.csv')
    
def connect_to_database():
    rs_port = 5439
    database_id = 'ads'
    rs_host = 'redshiftcluster-ulcxip6pepqm.clj0hthde0xh.eu-west-1.redshift.amazonaws.com'
    conn = psycopg2.connect(
        host=rs_host,
        port=rs_port,
        user='awsuser',
        password=PASS,
        database=database_id
        )
    return conn 

def read_from_csv(filename):
    with open(filename, "r") as data: # Loads all data from CSV to one variable that is a list of all data
        key_headers = ["timestamp", "store", "customer_name", "basket_items", "total_price", "cash_or_card", "card_number"]
        reader = DictReader(data, fieldnames = key_headers)
        data_list = []
        for row in reader:
            data_list.append(row)
        print("CSV File has been read")
    return data_list

def replace_empty_with_null(data_list): # Replaces any empty fields with None Type values for easy inserting
    for transaction in data_list:
        for key in  list(transaction.keys()):
            if transaction[key] == "":
                transaction[key] = None

def purge_dict_key(keyname, data_list): #removes specific key from all dictuionaries inside list
    for transaction in data_list:
        transaction.pop(keyname, None)

def extract_product_data(transaction): # takes an dictionary and seperates the basket items into a list of products
    product_list = transaction["basket_items"].split(", ")
    product_id_list = []
    flavour_id_list = []
    for products in product_list:
        new_entry = products.split(" - ") # splits individual products into name - flavour - price
        new_product = new_entry[0]
        new_price = new_entry[-1]
        if len(new_entry) > 2:
            new_flavour = new_entry[1] # checks if list has flavour in it
        else:
            new_flavour = None
        add_product_to_database(new_product, new_price, new_flavour)
        product_id_list.append(get_product_id(new_product))
        flavour_id_list.append(get_flavour_id(new_flavour))
    return product_id_list, flavour_id_list

def add_product_to_database(product_name, product_price, flavour = None): 
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" INSERT INTO  products (product_name, price)
        SELECT '{product_name}', '{product_price}'
        WHERE NOT EXISTS (SELECT product_name FROM products WHERE product_name = '{product_name}')
        """
        )
    if flavour != None:
        cur.execute(\
            f"""INSERT INTO flavours (flavour_name)
            SELECT '{flavour}'
            WHERE NOT EXISTS (SELECT flavour_name FROM flavours WHERE flavour_name = '{flavour}')
            """)
    conn.commit()
    cur.close()
    conn.close()
    
def add_store_to_database(store_name):
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" INSERT INTO stores (store_name)
        SELECT '{store_name}'
        WHERE NOT EXISTS (SELECT store_name FROM stores WHERE store_name = '{store_name}')
        """
        )
    conn.commit()
    cur.close()
    conn.close()

def add_customer_to_database(customer_name, store_id):
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" INSERT INTO customers (customer_name, store_id)
        SELECT '{customer_name}', {store_id}
        WHERE NOT EXISTS (SELECT customer_name, store_id FROM customers WHERE customer_name = '{customer_name}' AND store_id = {store_id})
        """
        )
    conn.commit()
    cur.close()
    conn.close()

def add_transaction_to_database(time_stamp, store_id, customer_id, total_price, payment_type):
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" INSERT INTO transactions (time_stamp, store_id, customer_id, total_price, payment_type)
        VALUES ('{time_stamp}', {store_id}, {customer_id}, {total_price}, '{payment_type}');
        """
        )
    conn.commit()
    cur.close()
    conn.close()

def add_products_to_basket(transaction_id, product_ids, flavour_ids):
    conn = connect_to_database()
    cur = conn.cursor()
    for i in range(len(product_ids)):
        cur.execute(\
            f"""INSERT INTO baskets (transaction_id, product_id, flavour_id)
            VALUES ({transaction_id}, {product_ids[i]}, %s)
            """, [flavour_ids[i]])
    conn.commit()
    cur.close()
    conn.close()
    
def get_product_id(product_name):
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" SELECT product_id from products WHERE product_name = '{product_name}'
        """)
    id = cur.fetchall()[0][0]
    cur.close()
    conn.close()
    return id

def get_flavour_id(flavour_name):
    conn = connect_to_database()
    cur = conn.cursor()
    if flavour_name == None:
        return None
    cur.execute(\
        f""" SELECT flavour_id from flavours WHERE flavour_name = '{flavour_name}'
        """)
    id = cur.fetchall()[0][0]
    cur.close()
    conn.close()
    return id

def get_store_id(store_name):
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" SELECT store_id from stores WHERE store_name = '{store_name}'
        """)
    id = cur.fetchall()[0][0]
    cur.close()
    conn.close()
    return id

def get_store_id(store_name):
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" SELECT store_id from stores WHERE store_name = '{store_name}'
        """)
    id = cur.fetchall()[0][0]
    cur.close()
    conn.close()
    return id

def get_transaction_id(time_stamp, store_id):
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" SELECT transaction_id from transactions WHERE time_stamp = '{time_stamp}' AND store_id = {store_id}
        """)
    id = cur.fetchall()[0][0]
    cur.close()
    conn.close()
    return id

def get_customer_id(customer_name, store_id):
    conn = connect_to_database()
    cur = conn.cursor()
    cur.execute(\
        f""" SELECT customer_id from customers WHERE customer_name = '{customer_name}' AND store_id = {store_id}
        """)
    id = cur.fetchall()[0][0]
    cur.close()
    conn.close()
    return id

def extract_transaction_data(file_name): # seperates all fields into variables and loads them into different functions to be mass added to DB
    data_list = read_from_csv(file_name)
    print("Data Read from CSV")
    for transaction in data_list:
        product_ids, flavour_ids = extract_product_data(transaction)
        store_name = transaction["store"]
        customer_name = hash_name(transaction["customer_name"])
        total_price = transaction["total_price"]
        payment_type = transaction["cash_or_card"]
        time_stamp = manipulate_time_to_iso8601(transaction["timestamp"])
        add_store_to_database(store_name)
        store_id = get_store_id(store_name)
        add_customer_to_database(customer_name, store_id)
        customer_id = get_customer_id(customer_name, store_id)
        add_transaction_to_database(time_stamp, store_id, customer_id, total_price, payment_type)
        transaction_id = get_transaction_id(time_stamp, store_id)
        add_products_to_basket(transaction_id, product_ids, flavour_ids)
    print("Data added to database")
        
def manipulate_time_to_iso8601(time_stamp): # Manipulates time to be ISO 8601 Compliant (YYYY/MM/DD)
    time_split = time_stamp[:10].split("/")
    end_time = time_stamp[10:]
    time_order = [2, 1, 0]
    iso8601 = [time_split[i] for i in time_order] # reorders current date format
    iso8601 = '/'.join(iso8601) + end_time
    return iso8601

def hash_name(name): # Hashes the name to protect sensitive data
    hash_object = hashlib.sha256(name.encode())
    hashed_name = hash_object.hexdigest()
    return hashed_name
